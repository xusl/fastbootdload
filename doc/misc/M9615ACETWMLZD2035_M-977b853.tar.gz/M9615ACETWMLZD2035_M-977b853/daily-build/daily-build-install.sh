#============================================================================
#
#                  D A I L Y    B U I L D    E N T R Y
#
# This script provide entry for daily build.
#
#
# Edit history
# ------------
#
# when          who    what, why, how
# ----------    ---    -----------------------------------------------------
# 2013-08-07    xdw    Create file
#
#
#============================================================================
#!/bin/sh

# This script should lie in "/tools/daily-build" directory, if not, need to update the path
curr_path=`pwd`
root_dir=${curr_path/\/tools\/daily-build/}
git_dir=$root_dir/.git
dst_dir=$git_dir/hooks
daily_build_files="daily-build.sh daily-build-trigger.sh post-commit post-merge"

# Check whether .git exists
check_git_dir() {
    if [ ! -e $git_dir ]; then
        echo "$git_dir doesn't exist, exit!"
        exit
    fi
}

# Configure daily build directory and build command
do_configuration() {
    read -p "Please specify build path [$HOME/daily-build]?" build_path
    if [ -z $build_path ]; then
        build_path=$HOME/daily-build
    fi
    echo "Build path:" $build_path

    select build_cmd in ../../*.sh other; do
        if [ $build_cmd = "other" ]; then
            read -p "Please specify build script?" build_cmd
        else
            build_cmd=${build_cmd/\.\.\/\.\.\//}
        fi
        break
    done

    if [ -z $build_cmd ]; then
        build_cmd="build_image.sh"
    fi
    echo "Build command:" $build_cmd

    read -p "Please specify build time [23:30]?" build_time
    if [ -z "$build_time" ]; then
        build_time="23:30"
    fi
    echo "Build time:" $build_time
}

generate_daily_build() {
# Generating build script
python -c """
for line in open('daily-build.template').readlines():
    if line.startswith('build_dir=<build_dir>'):
        line = 'build_dir=' + r'$build_path'
    elif line.startswith('repo_dir=<repo_dir>'):
        line = 'repo_dir=' + r'$git_dir'
    elif line.startswith('build_cmd=<build_cmd>'):
        line = 'build_cmd=' + r'$build_cmd'
    elif line.startswith('build_project=<build_project>'):
        line = 'build_project=' + r'$(basename $root_dir)'
    print(line.rstrip())
""" > "daily-build.sh"
}

generate_daily_build_trigger() {
python -c """
for line in open('daily-build-trigger.template').readlines():
    if line.startswith('build_time=<'):
        line = 'build_time=' + r'$build_time'
    print(line.rstrip())
""" > "daily-build-trigger.sh"
}

do_install() {
    # move build scripts to .git/hooks
    mv -f -t $dst_dir $daily_build_files 

    cd $dst_dir

    for f in $daily_build_files
    do
        if [ ! -x $f ]; then
            chmod a+x $f
        fi
    done

    sync_task="${build_time/*:/} ${build_time/:*/} * * * cd $root_dir && git pull"
    crontab -l >/dev/null 2>&1
    if [ $? -eq 0 ]; then
        crontab -l | grep -qF "$sync_task"
        if [ $? -eq 0 ]; then
            echo "daily build script have installed already, abort!"
            return
        else
            crontab - <<-EOF
$sync_task
$(crontab -l)
EOF
        fi
    else
        crontab - <<-EOF
$sync_task
EOF
    fi
}

do_uninstall() {
    cd $dst_dir
    
    for f in $daily_build_files
    do
        if [ -e $f ]; then
            echo "Removing $f ..."
            rm $f
        fi
    done

    root_dir=${root_dir//\//\\\/}
    crontab - <<-EOF
$(crontab -l | sed -e "/\* \* \* cd $root_dir\/* \&\& git pull/d")
EOF
}

if [ $0 = "./daily-build-install.sh" ]; then
    check_git_dir
    do_configuration
    generate_daily_build
    generate_daily_build_trigger
    cp post-commit.template post-commit
    cp post-merge.template post-merge
    echo "Installing daily build ..."
    do_install
elif [ $0 = "./daily-build-uninstall.sh" ]; then
    echo "Uninstalling daily build ..."
    do_uninstall
fi

